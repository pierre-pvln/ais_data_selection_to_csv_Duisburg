import json
import boto3
import pandas as pd
import urllib3
from datetime import datetime
import os
import tempfile
import bz2
import awswrangler as wr

def get_filename_datetime():
    now = datetime.now()
    return str(now.year) + "/" + str(now.month).zfill(2) + "/" + str(now.day).zfill(2) + "/" + "raw-" + now.strftime("%Y-%m-%d_%H:%M:%S")


def lambda_handler(event, context):

    # get settings
    s3 = boto3.client('s3')
    bucket_object = s3.get_object(Bucket='ais-datasets-json',
                                  Key='settings/limburg.json')
    serializedobject = bucket_object['Body'].read()
    SETTINGS = json.loads(serializedobject)

    # print("=============")
    # print(SETTINGS)
    
    # print("=============")    
    # print(get_filename_datetime())
    
    url = SETTINGS['aishub']['url']
    payload = {'username': SETTINGS['aishub']['username'],
               'format':   SETTINGS['aishub']['format'],
               'output':   SETTINGS['aishub']['output'],
               'compress': SETTINGS['aishub']['compress'],
               'latmin':   SETTINGS['aishub']['latmin'],
               'latmax':   SETTINGS['aishub']['latmax'],
               'lonmin':   SETTINGS['aishub']['lonmin'],
               'lonmax':   SETTINGS['aishub']['lonmax']
               }

    http = urllib3.PoolManager()
    req = http.request('GET', url, fields=payload)

    # Retrieve data from AIShub to temp file
    datafile = tempfile.mkstemp(prefix='aishub-collector-')
    os.write(datafile[0], req.data)
    os.close(datafile[0])

    # Read data using gunzip2 as json object
    with bz2.open(datafile[1], mode="rt", encoding="utf-8") as dataf:
        data = json.load(dataf)

    if data[0]['ERROR'] is not True:
        filename = get_filename_datetime()
        # Write data to json file on S3
        try:
            s3 = boto3.resource('s3')
            s3_object = s3.Object('ais-datasets-json', filename+".json")
            s3_object.put(Body=json.dumps(data),
                          Metadata={'year': str(datetime.now().year), 'month': str(datetime.now().month),
                                    'day': str(datetime.now().day), 'hour': str(datetime.now().hour)}, )
        except Exception as e:
            print("== json write error ==")
            print(e)
            pass

        # Write data to parquet file on S3
        try:
            if data[0]['RECORDS'] > 0:
                # print("=============")
                # print(data[1])
                df = pd.DataFrame.from_records(data[1])
                # print("=============")
                # print(df.columns)
                
                frame = df[
                    ['MMSI', 'TIME', 'LONGITUDE', 'LATITUDE', 'COG', 'SOG', 'HEADING', 'ROT', 'NAVSTAT', 'IMO', 'NAME', 'CALLSIGN',
                     'TYPE', 'A', 'B', 'C', 'D', 'DRAUGHT', 'DEST', 'ETA']]
                    
                # print("=============")
                # print(frame.columns)
                # print(frame.head(1))
                
                wr.s3.to_parquet(df=frame, 
                                 path="s3://ais-datasets-parquet/"+filename+".parquet"
                                 )

        except Exception as e:
            print("== parquet write error ==")
            print(e)
            pass

    # else:
    #    print(data)

    # Remove temporary file
    os.unlink(datafile[1])
    return
